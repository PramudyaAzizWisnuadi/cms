<?php

namespace App\Filament\Resources\CategoriGaleriResource\Pages;

use App\Filament\Resources\CategoriGaleriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCategoriGaleri extends CreateRecord
{
    protected static string $resource = CategoriGaleriResource::class;
}
