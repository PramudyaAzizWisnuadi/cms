<?php

namespace App\Filament\Resources\PromosiResource\Pages;

use App\Filament\Resources\PromosiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePromosi extends CreateRecord
{
    protected static string $resource = PromosiResource::class;
}
