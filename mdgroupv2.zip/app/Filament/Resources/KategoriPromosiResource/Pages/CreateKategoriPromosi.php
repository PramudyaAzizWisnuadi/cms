<?php

namespace App\Filament\Resources\KategoriPromosiResource\Pages;

use App\Filament\Resources\KategoriPromosiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKategoriPromosi extends CreateRecord
{
    protected static string $resource = KategoriPromosiResource::class;
}
