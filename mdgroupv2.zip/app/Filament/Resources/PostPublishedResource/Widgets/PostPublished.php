<?php

namespace App\Filament\Resources\PostPublishedResource\Widgets;

use Filament\Widgets\Widget;

class PostPublished extends Widget
{
    protected static string $view = 'filament.resources.post-published-resource.widgets.post-published';
}
